"use static";

export const AboutText = `Hacker's Hall is a website specifically designed to teach web application security. A website purposely
    designed with various security vulnerabilities, software developers can get first hand experience at the
    risks that a website is exposed to without the proper security approaches.`;


