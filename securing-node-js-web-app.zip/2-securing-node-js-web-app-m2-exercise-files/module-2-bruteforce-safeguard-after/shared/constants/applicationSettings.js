"use strict";

export default {
    serverPath: "http://localhost:7000",
}