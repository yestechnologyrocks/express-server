"use strict";
/* eslint-disable no-console */

import colors       from "colors";

console.log(colors.yellow("Starting in development mode!"));